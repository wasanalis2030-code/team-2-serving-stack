# Capacity Note

## The numbers

- Locked model: Qwen/Qwen2.5-1.5B-Instruct-AWQ
- Target p95 end-to-end latency: 8.0 seconds
- Knee concurrency: 32 (sweep-bounded)
- Tokens per second at the knee: 729.52
- p95 latency at the knee: 2.8438 seconds
- Max sustainable request rate: 7.03 requests per second
- Request errors: 0

## The limiting family

- Memory-bound tendency: throughput increased only slightly from concurrency 16 to 32 while p95 latency continued to rise, which is consistent with a decode memory-bandwidth ceiling.

## Why the knee, not the peak

- The knee is the highest tested concurrency that still satisfies the latency SLO, so it represents capacity the service can honestly promise rather than throughput alone.
