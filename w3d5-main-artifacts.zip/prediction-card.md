# W3D5 Prediction Card

- Locked model: Qwen/Qwen2.5-1.5B-Instruct-AWQ
- Predicted knee concurrency: 8
- Target p95 SLO: 8.0 seconds
